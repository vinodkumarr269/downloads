package com.prem.service;

import java.util.Optional;

import org.bouncycastle.asn1.x509.sigi.PersonalData;

import com.prem.model.Loan;
import com.prem.model.PersonalTable;
import com.prem.model.User;

public interface LoanService{

		public Optional<User> getUser(int i);
		
		public int addUser(User user);
		
		public String addpersonaldetails(PersonalTable personaldata);
		
		public int Knockout(Loan loan);
	
		//public int NewOrExisting(String username,String password,String amount_property_sq_area_code);*/
}

package com.prem.controller;

import java.util.Optional;

import org.bouncycastle.asn1.x509.sigi.PersonalData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.prem.model.Loan;
import com.prem.model.PersonalTable;
import com.prem.model.User;

import com.prem.service.LoanService;

@RestController
@RequestMapping("/User")
public class LoanController {


	@Autowired
	LoanService loanservice;
	
	@RequestMapping("/getuser/{id}")
	public Optional<User> getUser(@PathVariable("id") int id) {
		System.out.println("\n\n\n"+id+"\n\n\n\n");
		Optional<User> us=loanservice.getUser(id);
		return us;
	}
	
	@RequestMapping(value = "/saveUser" , method = RequestMethod.POST)
	public int addUser(@RequestBody User user){
			return loanservice.addUser(user);
	}
	
	@RequestMapping(value = "/savePersonalData" , method = RequestMethod.POST)
	public String addPersonalData(@RequestBody PersonalTable personaldata){
			return loanservice.addpersonaldetails(personaldata);
	}
	
	
	
	@RequestMapping("/knockUser")
	public int KnockoutUser(@RequestBody Loan loan) {
		System.out.println("\n\n\n"+loan+"\n\n\n");
		//return loanservice.Knockout(loan);
		return 10000;
	}
}

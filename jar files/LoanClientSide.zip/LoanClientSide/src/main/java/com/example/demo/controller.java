package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RestController
@RequestMapping("/")
public class controller {
	
	@Autowired
     UserRepository userRepo;
	
	@RequestMapping("/")
	public ModelAndView home(ModelAndView model){
		User user = new User();
		model.addObject("user", user);
		model.setViewName("Login");
		return model;
	}
	@RequestMapping("/authentication")
	public ModelAndView accountList(@ModelAttribute User user, ModelAndView model ) {
		
		model.addObject("user",user);
		if(userRepo.getAuthentication(user)) {
			user.setUserid(userRepo.getUserId(user));
			model.setViewName("Home");
			return model;
		} else {
			model.addObject("wrong","user Name and Password is Wrong");
			model.setViewName("Login");
			return model;
		}
	}
	
	@RequestMapping("/newuser")
	public ModelAndView newuser(ModelAndView model){
		User user = new User();
		model.addObject("user", user);
		model.setViewName("NewUser");
		return model;
	}
	
	@RequestMapping("/newdetail")
	public ModelAndView newDetail(@ModelAttribute User user, ModelAndView model){
		int id = userRepo.addUser(user);
		PersonalTable detail = new PersonalTable();
		model.addObject("id", id);
		detail.setUserid(id);
		model.addObject("detail", detail);
		model.setViewName("NewForm");
		return model;
	}
	
	@PostMapping("/register" )
	public ModelAndView register(@ModelAttribute PersonalTable detail,  ModelAndView model){
		String str = userRepo.register(detail);
		System.out.println("\n\n\n"+str+"\n\n\n");
		model.addObject("info", str);
		model.setViewName("save");
		return model;
	}
	
	@GetMapping("/applyloanNew/{id}" )
	public ModelAndView applyLoanNew(@PathVariable("id") int id, ModelAndView model){
		Loan loan = new Loan();
		loan.setUserid(id);
		model.addObject("loan", loan);
		System.out.println("\n\n\n"+loan.getUserid()+"\n\n\n");
		model.setViewName("Loan");
		System.out.println("\n\n\n"+loan+"\n\n\n");
		return model;
	}
	@GetMapping("/loanlist/{id}" )
	public ModelAndView loanList(@PathVariable("id") int id, ModelAndView model){
		List<Loan> loanlist = new ArrayList<Loan>();
		loanlist = userRepo.getAllLoan(id);
		model.addObject("loan",loanlist);
		model.setViewName("LoanList");
		return model;
		
	}
	
	@GetMapping("/applyloanExist/{id}" )
	public ModelAndView applyLoanExist(@PathVariable("id") int propertyid, ModelAndView model){
		long amount = userRepo.loanCheckExist(propertyid);
		Loan loan = new Loan();
		loan.setPropertyid(propertyid);
		model.addObject("loan",loan);
		model.addObject("amount",amount);
		model.setViewName("Checkout");
		return model;
		
	}
	
	@PostMapping("/checkout" )
	public ModelAndView ckeckout(@ModelAttribute Loan loan, ModelAndView model){
		model.addObject("loan",loan);
		if(userRepo.checkout(loan)) {
			model.addObject("confirm","Loan Processed Successfully");
		} else {
			model.addObject("confirm","Loan declined");
		}
		model.addObject("amount",userRepo.loanCheckExist(loan.getPropertyid()));
		model.setViewName("Checkout");
		return model;
		
	}
	
	@PostMapping("/loancheck" )
	public ModelAndView loanCheck(@ModelAttribute Loan loan,  ModelAndView model){
		System.out.println("\n\n\n"+loan+"\n\n\n");
		model.addObject("loan", loan);
		long amount = userRepo.loanCheck(loan);
		System.out.println("\n\n\n"+amount+"\n\n\n");
		if(amount == -404) {
			model.addObject("exist", "You are not eligible to Take Loan");
			model.setViewName("Loan");
			return model;
		} else {
			model.addObject("amount", amount);
			model.setViewName("Checkout");
			return model;
		}
		
		
	}
	
	@GetMapping("/applyloanNewProduct/{id}" )
	public ModelAndView applyLoanNewProduct(@PathVariable("id") int id, ModelAndView model){
		Loan loan = new Loan();
		loan.setUserid(id);
		model.addObject("loan", loan);
		System.out.println("\n\n\n"+loan.getUserid()+"\n\n\n");
		model.setViewName("Loan");
		System.out.println("\n\n\n"+loan+"\n\n\n");
		return model;
	}
	
/*	@RequestMapping("/accountDetails")
	public String accountDetails(@RequestParam("number") String id, Model model) {
		model.addAttribute("account", accountRepository.getAccount(id));
		return "accountDetails";
	}*/
}


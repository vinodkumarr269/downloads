# spel

The project contains the code examples for this [article]( https://dzone.com/articles/learn-spring-expression-language-with-examples) published in dzone.

The examples include:
*	Basic examples of SpEL
*	Example of HTML email template with SpEL

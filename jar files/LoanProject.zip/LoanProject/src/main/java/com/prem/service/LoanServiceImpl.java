package com.prem.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.bouncycastle.asn1.x509.sigi.PersonalData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prem.model.Loan;
import com.prem.model.PersonalTable;
import com.prem.model.User;
import com.prem.repository.LoanRepository;
import com.prem.repository.PersonalDataRepository;
import com.prem.repository.UserRepository;

@Service
public class LoanServiceImpl implements LoanService {

	@Autowired
	UserRepository repo;

	@Autowired
	PersonalDataRepository repopersonal;

	@Autowired
	LoanRepository loanrepo;

	@Override
	public Optional<User> getUser(int id) {
		Optional<User> us = repo.findById(id);
		return us;
	}

	@Override
	public int addUser(User user) {
		User tempuser = repo.save(user);
		List<User> listus = repo.findByUsername(tempuser.getUsername());
		User us1 = listus.get(0);
		if (us1 != null) {
			return us1.getUserid();
		} else {
			return 0;
		}
	}

	@SuppressWarnings("unused")
	@Override
	public String addpersonaldetails(PersonalTable personaldata) {
		Random rand = new Random();
		PersonalTable temppersonal = repopersonal.save(personaldata);
		int credit = rand.nextInt(500) + 500;
		temppersonal.setCreditscore(credit);
		String str = "";
		if (temppersonal != null) {
			str = "PersonalDetails saved successfully";
		} else {
			str = "Not Saved";
		}
		return str;
	}

	@Override
	public int Knockout(Loan loan) {
		@SuppressWarnings("unused")
		boolean flag = false;
		int existingloan = 0;
		Random rand = new Random();
		int premium = rand.nextInt(1);
		int i = 0;
		PersonalTable detail = new PersonalTable();
		detail = repopersonal.findById(loan.getUserid()).get();
		String legal = detail.getLegalresident();
		int credit = detail.getCreditscore();
		List<Loan> loanlist = (List<Loan>) loanrepo.findAll();
		for (int m = 0; m < loanlist.size(); m++) {
			if (loanlist.get(m).getPropertyid() == loan.getPropertyid()) {
				existingloan = loanlist.get(m).getAmount();
				flag = true;
			}
		}
		if (flag = false) {
			if (legal == "yes" && credit > 600) {
				if (premium == 1) {
					i = credit * 100 + (loan.getProperty_sq() * loan.getArea_code());
				}
				if (premium == 0) {
					i = loan.getProperty_sq() * loan.getArea_code();
				}
			}else {
				i=100001;
			}
		} else {
			if (premium == 1) {
				i = existingloan - (credit * 100 + (loan.getProperty_sq() * loan.getArea_code()));
			}
			if (premium == 0) {
				i = existingloan - (loan.getProperty_sq() * loan.getArea_code());
			}

		}
		return i;

	}


}
